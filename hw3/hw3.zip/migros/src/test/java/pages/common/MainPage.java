package pages.common;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pages.AbstractPage;
import utils.Browser;

public class MainPage extends AbstractPage
{
    public MainPage(Browser browser)
    {
        super(browser);
    }

    @FindBy(id = "membership-login-link")
    public WebElement loginButton;

    @FindBy(linkText = "Et, Tavuk, Balık")
    public WebElement meatFishChichkenMenu;
    
    @FindBy(css = "a[data-monitor-ga-action='Kırmızı Et']")
    public WebElement meatCategory;

    @FindBy(linkText = "Dana Yemeklik Kuşbaşı Kg")
    public WebElement meatKusbasi;

    @FindBy(linkText = "Bebek, Oyuncak")
    public WebElement bebekOyuncakMenu;
    
    @FindBy(css = "a[data-monitor-ga-action='Bebek Bezi']")
    public WebElement bebekBezi;
    
    @FindBy(xpath = "//*[@id=\"page-area\"]/div/div/div[1]/div[1]/div/div[3]/ul/li/ul/li[1]/a/div/span[2]")
    public WebElement prima;
    
    @FindBy(css = "span[data-request-param='216']")
    public WebElement checkDortBeden;
    
    @FindBy(css = "a[data-monitor-ga-label='4 Beden']")
    public WebElement dortBeden;
    
    @FindBy(linkText = "Önce En Yüksek Fiyat")
    public WebElement enPahaliyaGore;
    
    @FindBy(xpath = "//*[@id=\"product-list-sort\"]/nav/button/div/span")
    public WebElement sirala;
    
    @FindBy(xpath = "//*[@id=\"product-list\"]/div[2]/div[1]/div/form/div[1]/h5/a")
    public WebElement enPahaliUrun;
    
    @FindBy(xpath = "//*[@id=\"store-product-primary-price\"]")
    public WebElement enPahaliUrunFiyat;
    
    @FindBy(xpath = "//*[@id=\"product-page\"]/div/div/div[1]/div[2]/div/div[2]/form/div/div[2]/button")
    public WebElement sepeteEkle;
    
    @FindBy(xpath = "//*[contains(@class, 'value')]")
    public List<WebElement> price;
    
    @FindBy(css = ".shoping-cart-icon-block .fa-shopping-cart")
    public WebElement shoppingBasketButton;

    @FindBy(className = "progress-bar-text")
    public WebElement progressBarText;

    @FindBy(css = ".action-td .plus-orange")
    public WebElement plusButton;

    @FindBy(className = "rubbish")
    public WebElement trashButton;

    @FindBy(className = "go-to-basket-button")
    public WebElement goToBasketButton;
    
}
