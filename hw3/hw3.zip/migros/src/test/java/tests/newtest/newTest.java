package tests.newtest;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import pages.common.MainPage;

import tests.AbstractTest;

public class newTest extends AbstractTest
{
	WebElement e;
    @SuppressWarnings("deprecation")
	@Test
    public void testNewScenerio()
    {
        //login(context.getInternalProps().getUsername(), context.getInternalProps().getPassword());
        //clearBasket();
        MainPage mainPage = new MainPage(browser);
        Assert.assertTrue("Could not open Bebek Oyuncak category", browser.waitAndClick(mainPage.bebekOyuncakMenu));
        String title1 = browser.getTitle();
        Assert.assertEquals("Bebek, Oyuncak - Migros", title1);
     
        Assert.assertTrue("Could not open Bebek Bezi category", browser.waitAndClick(mainPage.bebekBezi));
        String title2 = browser.getTitle();
        Assert.assertEquals("Bebek Bezleri, Bebek Bezi Kampanyaları - Migros", title2);
        
        Assert.assertTrue("Could not open Prima page", browser.waitAndClick(mainPage.prima));
        String title3 = browser.getTitle();
        Assert.assertEquals("Prima Bebek Bezleri, Bebek Bezi Kampanyaları - Migros", title3);
        
        Assert.assertTrue("Could not open 4 Beden page", browser.waitAndClick(mainPage.dortBeden));
        String isChecked = mainPage.checkDortBeden.getAttribute("class");
        Assert.assertEquals("icheckbox_minimal-orange checked", isChecked);
        
        browser.waitAndClick(mainPage.sirala);
        Assert.assertTrue("Could not find sort from highest button", browser.waitAndClick(mainPage.enPahaliyaGore));
        String biggest = mainPage.price.get(0).getText();
        String replaceString = biggest.replace(" TL", "");
        replaceString = replaceString.replace(",", ".");
        biggest = replaceString;
        float bigint = Float.parseFloat(biggest);
        float bigint2 = bigint;

        for(WebElement value: mainPage.price)
        {
        	String small = value.getText();
        	String replacedString=small.replace(" TL", "");
        	replacedString=replacedString.replace(",", ".");
        	small = replacedString;
        	float smallint = Float.parseFloat(small);
        	if(bigint2 >= smallint)
        	{
        		bigint2 = smallint;
        		System.out.println(bigint2);
        	}
        	else 
        	{
        		Assert.assertTrue("Prices not descending", true);
        	}
        }
        
        browser.waitAndClick(mainPage.enPahaliUrun);
        boolean sepet = browser.isElementDisplayed(mainPage.sepeteEkle);
        Assert.assertTrue("Ürün sayfasına ulaşılamadı", sepet);
        String enpahali = mainPage.enPahaliUrunFiyat.getText();
        enpahali = enpahali.replace(" TL", "");
        enpahali = enpahali.replace(",", ".");
    	float enpahaliFiyat = Float.parseFloat(enpahali);
    	Assert.assertEquals(bigint, enpahaliFiyat, 0.0001);
    	
    }
}
