# migros
Migros Case


- Download ChromeDriver

  http://chromedriver.chromium.org/downloads

  ChromeDriver WebDriver is an open source tool for automated testing of webapps across many browsers. It provides capabilities for navigating to web pages, user input, JavaScript execution, and more. ChromeDriver is a standalone server that implements the W3C WebDriver standard. ChromeDriver is available for Chrome on Android and Chrome on Desktop (Mac, Linux, Windows and ChromeOS).




- Put your chromedriver executable file into "/opt/" directory or whereever you want

  System.setProperty("webdriver.chrome.driver", "/opt/chromedriver");
